# icon 0.1.0

* First release.
* Allows font icons to be easily included in R Markdown documents.
* Provides support for Font Awesome, Academicons, and Ionicons icon libraries.
* Some control options for the icons are possible, including icon colour, rotation, size and animations.
